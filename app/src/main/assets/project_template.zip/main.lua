_CX = display.contentCenterX
_CY = display.contentCenterY

display.newText("Hello Solar2D!", _CX, _CY, null, 20)