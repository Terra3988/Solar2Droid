application =
{
	content =
	{
		width = 720,
		height = 1280,
		scale = "letterbox",
		fps = 60
	}
}